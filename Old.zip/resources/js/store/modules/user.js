import Cookies from "js-cookie";
import router from "../../router/router";

const state = {
    authenticated: Cookies.get('token') !== undefined,
    token: Cookies.get('token') || '',
    user: {},
    user_data_ready: false
};

const mutations = {
    setToken(state, token) {
        state.token = token;
    },
    setAuthenticated(state, truthy) {
        state.authenticated = truthy;
    },
    setUserDataReady(state, truthy) {
        state.user_data_ready = truthy;
    },
    setUser(state, user) {
        state.user = user;
    },
    removeUser(state) {
        state.user = {};
    }
};

const actions = {
    authenticate(context, data) {
        let token = `Bearer ${data.token}`;
        Cookies.set('token', token, {
            expires: context.getters.sessionLifetime,
            domain: '.' + context.getters.domain
        });
        context.commit('setAuthenticated', true);
        context.commit('setToken', token);
    },
    async fetchUserData(context) {
        let userData = await axios.get('/api/v1/users?me');

        if (userData.hasOwnProperty('data')) {
            context.commit('setUser', userData.data.data);
            context.commit('setUserDataReady', true);
        } else {
            context.dispatch('loggedOut');
        }
    },
    refreshSession(context) {
        // If session is ended, and the user tries to access to a page, we log them out
        if (!Cookies.get('token')) {
            context.dispatch('loggedOut');
            router.push('/');
            return;
        }

        Cookies.set('token', Cookies.get('token'), {
            expires: context.getters.sessionLifetime,
            domain: '.' + context.getters.domain
        });
    },
    logout(context, urlForRedirect = null) {
        axios.post('/api/v1/auth/logout').then(response => {
            context.dispatch('loggedOut').then(() => {
                router.push(urlForRedirect ? urlForRedirect : "/");
            });
        }).catch(error => {
            context.dispatch('loggedOut').then(() => {
                router.push("/");
            });
        });
    },
    loggedOut(context) {
        // do some things in here when a user has logged out.
        Cookies.remove('token', { path: '', domain: '.' + context.getters.domain });
        context.commit('setAuthenticated', false);
        context.commit('removeUser');
    }
};

const getters = {
    authenticated: (state) => state.token.length > 0,
    loggedIn: (state) => {
        return (state.authenticated && state.user_data_ready);
    },
    hasSubscription: (state) => {
        return (state.user && state.user.hasOwnProperty('subscription') && state.user.subscription);
    },
    token: (state) => {
        return Cookies.get('token');
    },
    needUserData: (state) => {
        return state.authenticated && !state.user_data_ready;
    },
    menuData: (state) => {
      return (state.user.hasOwnProperty('menu') && state.user.menu);
    },
    domain: (state) => {
        let hostName = window.location.hostname;
        let domain = hostName;
        /*if (hostName != null) {
            let parts = hostName.split('.').reverse();
            if (parts != null && parts.length > 1) {
                domain = parts[1] + parts[0];
            }
        }*/
        return domain;
    },
    userRole: state => (state.user.hasOwnProperty('role')) ? state.user.role.tk_name : null,
    sessionLifetime: state => 10,
    account: (state) => (state.hasOwnProperty('user')) ? state.user.account : false,
};

export default {
    state: state,
    mutations,
    actions,
    getters
}
