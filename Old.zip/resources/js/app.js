import './bootstrap';
import Vue from 'vue';
import App from './components/App';
import router from "./router/router";
import store from "./store/index";
import vuetify from "./plugins/vuetify";
import stripeLoader from "./stripe/stripe";

window.Vue = require('vue');
window.bus = new Vue({});
stripeLoader.initialize();
router.initialize();

const app = new Vue({
    el: '#app',
    vuetify,
    components: {
        App
    },
    router,
    store
});
