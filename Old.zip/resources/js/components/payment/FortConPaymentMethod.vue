<template>
    <div>
        <v-row>
            <v-col md="4" sm="12">
                <p>Before subscribing to a plan, you need to save a payment method. We take special care in ensuring that we do not share your details with anyone.</p>
            </v-col>
            <v-col md="6" sm="12">
                <v-card outlined>
                    <v-card-text>
                        <!--Form-->
                        <v-form ref="_create_payment_methods">
                            <div id="card-errors" role="alert"></div>
                            <v-row>
                                <v-col cols="12" md="6" sm="12">
                                    <v-text-field v-model="name" label="Name" placeholder="John Doe" filled :rules="requiredFieldRule"></v-text-field>
                                </v-col>
                                <v-col cols="12" md="6" sm="12">
                                    <v-text-field v-model="email" label="Email address" placeholder="john.doe@email.com" :rules="emailValidationRules"
                                                  filled></v-text-field>
                                </v-col>
                            </v-row>

                            <div class="mimic-input mb-5 mt-3">
                                <p class="caption">Card Number</p>
                                <div id="card-element"></div>
                            </div>

                            <v-btn :loading="loading" dark @click="savePaymentMethod">Save Payment Method</v-btn>
                        </v-form>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </div>
</template>

<script>
    import {mapGetters} from "vuex";

    export default {
        computed: {
            ...mapGetters(["emailValidationRules", "numericFieldRule", "requiredFieldRule"]),
        },
        data() {
            return {
                loading: false,
                stripe: null,
                name: null,
                email: null,
                userCount: 1,
                stripeStyle: {
                    base: {
                        color: "#32325d",
                        fontSmoothing: "antialiased",
                        fontSize: "16px",
                        "::placeholder": {
                            color: "#aab7c4"
                        }
                    },
                    invalid: {
                        color: "#fa755a",
                        iconColor: "#fa755a"
                    },
                },
                stripeElements: null,
                cardElement: null,
                paymentIntent: null,
                paymentMethods: [],
            };
        },
        methods: {
            async mountStripe() {
                this.loading = true;
                this.stripe = Stripe(process.env.MIX_STRIPE_KEY);
                this.stripeElements = this.stripe.elements();
                this.cardElement = this.stripeElements.create('card', this.stripeStyle);
                await this.cardElement.mount('#card-element');
                this.loading = false;
                this.cardElement.addEventListener('change', ({error}) => {
                    const displayError = document.getElementById('card-errors');
                    if (error) {
                        displayError.textContent = error.message;
                    } else {
                        displayError.textContent = '';
                    }
                });
            },
            getIntent() {
                this.loading = true;
                axios.get('/api/v1/payment/paymentIntent')
                    .then(response => {
                        this.loading = false;
                        this.paymentIntent = response.data.data;
                    });
            },
            async savePaymentMethod() {
                this.loading = true;
                if (this.$refs._create_payment_methods.validate()) {
                    const { setupIntent, error } = await this.stripe.confirmCardSetup(
                        this.paymentIntent.client_secret, {
                            payment_method: {
                                card: this.cardElement,
                                billing_details: {
                                    name: this.name
                                }
                            }
                        }
                    );

                    if (error) {
                        this.loading = false;
                        console.log(consoleBad, error.message);
                    } else {
                        console.log(consoleGood, 'Saving payment methods');
                        // complete the subscription process
                        let data = {
                            payment_method: setupIntent.payment_method,
                        };

                        axios.post('/api/v1/payment/savePaymentMethod', data).then(response => {
                            this.loading = false;
                            this.paymentMethods = response.data.data;
                            this.$emit('payment-method-saved', this.paymentMethods);
                        });
                    }
                }
            },
        },
        mounted() {
            this.mountStripe();
            this.getIntent();
        }
    }
</script>

<style scoped>
    .mimic-input {
        padding: 12px;
        background: rgba(0, 0, 0, 0.06);
        border-bottom: 1px solid rgba(0, 0, 0, 0.15);

        -webkit-border-top-left-radius: 5px;
        -webkit-border-top-right-radius: 5px;
        -moz-border-radius-topleft: 5px;
        -moz-border-radius-topright: 5px;
        border-top-left-radius: 5px;
        border-top-right-radius: 5px;
    }
</style>
