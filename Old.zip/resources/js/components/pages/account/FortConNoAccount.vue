<template>
    <div class="text-center">
        <v-img src="../../../../img/424324355465er.svg" position="center center" height="210" width="300"
               style="margin-top: 100px" class="mb-10 img-center"></v-img>
        <p class="headline">Opps...</p>
        <p>It does seem like you are not attached to an account. Select one of the following actions to
            perform.</p>

        <v-btn rounded depressed color="primary" dark>Request access to account</v-btn>
        <v-btn rounded depressed color="secondary" dark>Create your account</v-btn>
    </div>
</template>

<script>
    export default {
        name: "FortConNoAccount"
    }
</script>
