<template>
    <div class="mt-10 text-center">
        <p class="display-2 font-weight-thin mb-10">Scalable pricing without fuss...</p>
        <p>Our pay-per-seat model is based on two levels of users: Core Users and Collaborators.<br/>
            No implementation fees. Unlimited contract storage.</p>

        <div class="flex">
            <div class="d-inline-flex">monthly</div>
            <v-switch class="d-inline-flex ml-3" flat v-model="annually" inset></v-switch>
            <div class="d-inline-flex">annually</div>
        </div>

        <v-card class="mx-auto mt-10" max-width="70%" flat>
            <v-simple-table>
                <template v-slot:default>
                    <thead>
                    <tr v-if="selectedPlan">
                        <th class="text-left"></th>
                        <th class="text-left">
                            <p class="headline font-weight-bold">${{ selectedPlan.tiers[0].unit_amount / 100 }}</p>
                            <p class="subtitle-2">Core User<br/>billed {{ selectedPlan.nickname }}</p>
                        </th>
                        <th class="text-left">
                            <p class="headline font-weight-bold">${{ selectedPlan.tiers[1].unit_amount / 100 }}</p>
                            <p class="subtitle-2">per extra user <br/>billed {{ selectedPlan.nickname }}</p>
                        </th>
                    </tr>
                    </thead>
                    <tbody class="text-left">
                    <tr>
                        <td>Unlimited contracts</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Unlimited contract templates</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Reporting and metrics</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Team management</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Manage user permissions</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Real time signatures</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Emails and alerts</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Exports to PDF</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    <tr>
                        <td>Contract to project management</td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                        <td><v-icon class="ml-5">mdi-check-outline</v-icon></td>
                    </tr>
                    </tbody>
                </template>
            </v-simple-table>

            <div class="text-center mt-10">
                <v-btn @click="toPaymentPage" depressed rounded color="primary" dark>Subscribe now</v-btn>
            </div>
        </v-card>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                annually: true,
                plans: [],
                selectedPlan: null
            }
        },
        computed: {

        },
        watch: {
            annually: function () {
                this.setSelectedPlan();
            }
        },
        methods: {
            getPlans() {
                axios.get('/api/v1/public/plans?getActivePlans').then(response => {
                    this.plans = response.data.data;
                    this.setSelectedPlan();
                });
            },
            async setSelectedPlan() {
                let planObj = await this.plans.find(plan => {
                    return (this.annually) ? plan.nickname === 'annually' : plan.nickname === 'monthly';
                });

                planObj.tiers = (typeof planObj.tiers === 'string') ? JSON.parse(planObj.tiers) : planObj.tiers;
                this.selectedPlan = planObj;
            },
            toPaymentPage() {
                this.$router.replace({name:'payment', params:{ selectedPlan: this.selectedPlan }});
            }
        },
        mounted() {
            this.getPlans();
        }
    }
</script>

<style scoped>
    .tenure-switch {
        width: 100px;
        margin: 0 auto;
    }
</style>
