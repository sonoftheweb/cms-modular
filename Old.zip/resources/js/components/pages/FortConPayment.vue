<template>
    <div class="pa-10">
        <fort-con-header/>
        <v-expansion-panels v-model="opened">
            <v-expansion-panel>
                <v-expansion-panel-header disable-icon-rotate :hide-actions="hideIcon">
                    Manage payment method
                    <template v-slot:actions>
                        <v-icon color="error">mdi-alert-circle</v-icon>
                    </template>
                </v-expansion-panel-header>
                <v-expansion-panel-content>
                    <fort-con-payment-method @payment-method-saved="methodAdded"/>
                </v-expansion-panel-content>
            </v-expansion-panel>

            <v-expansion-panel v-if="selectedPlan">
                <v-expansion-panel-header :hide-actions="false">Select user count and make payment</v-expansion-panel-header>
                <v-expansion-panel-content>
                    <v-row>
                        <v-col cols="12" md="6" sm="12">
                            <v-card outlined>
                                <v-card-text>

                                    <p>Please fill in the form below to make a payment. You should get an email from us about your
                                        payment when it's confirmed. Do report any issue you have with making payment.</p>

                                    <!--Form-->
                                    <v-form ref="_payment_form">
                                        <v-row>
                                            <v-col cols="12" md="6" sm="12">
                                                <v-text-field v-model="userCount" type="number" filled :rules="requiredFieldRule"
                                                              label="Number of users"></v-text-field>
                                            </v-col>
                                            <v-col cols="12" md="6" sm="12" class="pt-2">
                                                <small>How many users are you inviting to the fort? You may create the users after
                                                    subscribing
                                                    or invite users to join on your account.</small>
                                            </v-col>
                                        </v-row>

                                        <v-row v-if="paymentMethods.length > 1">
                                            <v-col md="6" sm="12">
                                                <v-select
                                                    :items="paymentMethods"
                                                    label="Payment Method"
                                                    filled
                                                    v-model="selectedPaymentMethod"
                                                    item-value="id"
                                                >
                                                    <template v-slot:item="{item, index}">
                                                        **** **** **** {{ item.last_four }} {{ item.brand }} expires: {{ item.exp_month }} / {{ item.exp_year }}
                                                    </template>
                                                    <template v-slot:selection="{ item, index }">
                                                        **** **** **** {{ item.last_four }} {{ item.brand }}
                                                    </template>
                                                </v-select>
                                            </v-col>
                                            <v-col md="6" sm="12">
                                                <v-checkbox
                                                    v-model="makeDefault"
                                                    label="Make default payment method"
                                                ></v-checkbox>
                                            </v-col>
                                        </v-row>

                                        <div class="hidden-md-and-up">
                                            <p>Note that you'd be making a payment of <strong>{{ priceFormatted(calculatePrice)
                                                }}</strong> for your <strong>{{ (selectedPlan.nickname === "annually") ? 'annual' :
                                                'monthly' }}</strong> plan.</p>
                                        </div>

                                        <v-btn :loading="loading" dark @click="submitPayment">Pay {{ priceFormatted(calculatePrice) }}</v-btn>
                                    </v-form>
                                </v-card-text>
                            </v-card>
                        </v-col>
                        <v-col cols="12" md="4" class="hidden-sm-and-down">
                            <v-card dark>
                                <v-card-text>
                                    <p class="headline">Breakdown</p>
                                    <p class="heading">You'd be making a payment of <strong>{{
                                        priceFormatted(calculatePrice) }}</strong> for your <strong>{{ (selectedPlan.nickname ===
                                        "annually") ? 'annual' : 'monthly' }}</strong> plan.</p>
                                    <p>This subscription includes all the features available on the platform. Breakdown
                                        below... </p>

                                    <v-row no-gutters>
                                        <v-col cols="12" md="4">Tenure</v-col>
                                        <v-col cols="12" md="8">{{ selectedPlan.nickname }}</v-col>
                                    </v-row>

                                    <v-row no-gutters>
                                        <v-col cols="12" md="4">Initial user</v-col>
                                        <v-col cols="12" md="8">{{ priceFormatted(selectedPlan.tiers[0].unit_amount / 100) }}
                                        </v-col>
                                    </v-row>

                                    <v-row no-gutters>
                                        <v-col cols="12" md="4">Additional users</v-col>
                                        <v-col cols="12" md="8">{{ priceFormatted((selectedPlan.tiers[1].unit_amount / 100) *
                                            (userCount - selectedPlan.tiers[0].up_to)) }} for {{ userCount -
                                            selectedPlan.tiers[0].up_to }} users ({{
                                            priceFormatted(selectedPlan.tiers[1].unit_amount / 100) }} / user)
                                        </v-col>
                                    </v-row>

                                    <p class="mt-5">If you are satisfied, continue to secure payment or contact support for more details on issues you may be having.</p>
                                </v-card-text>
                            </v-card>
                        </v-col>
                        <v-col cols="12" md="2" class="hidden-sm-and-down"></v-col>
                    </v-row>
                </v-expansion-panel-content>
            </v-expansion-panel>
        </v-expansion-panels>
    </div>
</template>

<script>
    import {mapGetters} from "vuex";
    import "@stripe/stripe-js";
    import FortConHeader from "../utils/FortConHeader";
    import FortConPaymentMethod from "../payment/FortConPaymentMethod";

    export default {
        props: ["selectedPlan"],
        components: {
            FortConHeader,
            FortConPaymentMethod
        },
        computed: {
            ...mapGetters(["priceFormatted", "requiredFieldRule"]),
            calculatePrice() {
                let price = this.price;
                if (this.userCount > this.selectedPlan.tiers[0].up_to) {
                    price += (this.selectedPlan.tiers[1].unit_amount / 100) * (this.userCount - this.selectedPlan.tiers[0].up_to);
                } else {
                    price = this.selectedPlan.tiers[0].unit_amount / 100;
                }
                return price;
            }
        },
        data() {
            return {
                loading: false,
                price: null,
                userCount: 1,
                paymentIntent: null,
                paymentMethods: [],
                opened: 1,
                hideIcon: true,
                selectedPaymentMethod: null,
                makeDefault: false
            };
        },
        watch: {
            paymentMethods (val) {
                if (val.length < 1) {
                    this.opened = 0;
                    this.hideIcon = false;
                } else {
                    this.opened = 1;
                    this.selectedPaymentMethod = val[0];
                    this.makeDefault = true;
                }
            }
        },
        methods: {
            getPaymentMethods() {
                axios.get('/api/v1/payment/paymentMethods')
                    .then(response => {
                        this.paymentMethods = response.data.data;
                    });
            },
            submitPayment() {
                if (this.$refs._payment_form.validate()) {
                    this.loading = true;
                    let data = {
                        pm: this.selectedPaymentMethod,
                        plan: this.selectedPlan.nickname,
                        seat_count: this.userCount,
                        make_default_payment_method: this.makeDefault
                    };
                    axios.post('/api/v1/payment/subscribe', data)
                        .then(response => {
                            bus.$emit('alert', response.data);
                            this.$store.dispatch("fetchUserData").then(() => {
                                this.loading = false;
                                this.$router.push('/dashboard');
                            });
                        }).catch(err => {
                            this.loading = false;
                            bus.$emit('error', {
                                displayAlert: 'error',
                                message: 'Something went bang! Contact support ASAP!'
                            })
                        });
                }
            },
            methodAdded(value) {
                this.paymentMethods = value;
                this.hideIcon = true;
            }
        },
        mounted() {
            if (!this.selectedPlan) {
                this.$router.push('/subscribe');
            } else {
                this.getPaymentMethods();
                this.price = this.selectedPlan.tiers[0].unit_amount / 100;
            }
        }
    }
</script>

<style scoped>
    .minified {
        height: 0px !important;
    }
</style>
