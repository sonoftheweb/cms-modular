<template>
    <div>
        <fort-con-header/>

        <v-row class="my-10">
            <v-col md="4" sm="12">
                <p>
                    This account has {{account.settings.seats}} seats.
                </p>
                <small>
                    Manage all your users and their data. Note that users are tied to a seat and if you run out of seats, you cannot
                    add new users to your account.
                </small>
            </v-col>
        </v-row>

        <fort-con-smart-table
            :key="key"
            :selectable="true"
            :searchable="true"
            :url="listUrl"
            :view="viewUrl"
            :update="updateUrl"
            :delete="deleteUrl"
            @add-item="addDialog = true"
            @edit-item="toggleUpdateForm($event)"
            @delete-item="deleteUser($event)"
        />
        <v-dialog max-width="80%" hide-overlay transition="dialog-bottom-transition" v-model="addDialog">
            <v-card flat>
                <v-toolbar dark color="indigo darken-4" flat>
                    <v-toolbar-title>Add new user</v-toolbar-title>
                    <v-spacer></v-spacer>
                    <v-btn icon dark @click="addDialog = false">
                        <v-icon>mdi-close</v-icon>
                    </v-btn>
                </v-toolbar>
                <v-card-text class="my-5">
                    <p>Please fill in the form below to add a new user.<br/> The user will be invited to join the account and will have the opportunity to select his password.</p>
                    <v-form ref="form" lazy-validation class="mt-10">
                        <div class="title mb-3">User information</div>
                        <v-row>
                            <v-col md="4" sm="12">
                                <v-text-field
                                    v-model="newUser.first_name"
                                    label="First name *"
                                    placeholder="John"
                                    :rules="requiredFieldRule"
                                    filled
                                ></v-text-field>
                            </v-col>
                            <v-col md="4" sm="12">
                                <v-text-field
                                    v-model="newUser.last_name"
                                    label="Last name *"
                                    placeholder="Doe"
                                    :rules="requiredFieldRule"
                                    filled
                                ></v-text-field>
                            </v-col>
                            <v-col md="4" sm="12">
                                <v-text-field
                                    v-model="newUser.email"
                                    label="Email address *"
                                    placeholder="john.doe@example.com"
                                    :rules="emailValidationRules"
                                    filled
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <div class="title my-3">Company information</div>
                        <v-row>
                            <v-col md="4" sm="12">
                                <v-text-field
                                    v-model="newUser.attributes.job_title"
                                    label="Job title *"
                                    placeholder="What position does the user hold?"
                                    filled
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <div class="title my-3">Contact information</div>
                        <v-row>
                            <v-col md="4" sm="12">
                                <v-text-field
                                    v-model="newUser.attributes.mobile_phone"
                                    label="Mobile phone number"
                                    placeholder="Enter mobile phone number here"
                                    filled
                                ></v-text-field>
                            </v-col>
                            <v-col md="3" sm="12">
                                <v-text-field
                                    v-model="newUser.attributes.phone"
                                    label="Phone number *"
                                    placeholder="Phone number"
                                    :rules="requiredFieldRule"
                                    filled
                                ></v-text-field>
                            </v-col>
                            <v-col md="1" sm="12">
                                <v-text-field
                                    v-model="newUser.attributes.ext"
                                    label="Extension"
                                    placeholder="***"
                                    filled
                                ></v-text-field>
                            </v-col>
                        </v-row>
                        <v-btn @click="addUser" depressed rounded color="primary" dark>Add user</v-btn>
                        <v-btn @click="addDialog = false" depressed rounded dark>Close</v-btn>
                    </v-form>
                </v-card-text>
            </v-card>
        </v-dialog>
        <fort-con-confirm v-if=""/>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';
    import FortConHeader from "../../utils/FortConHeader";
    import FortConSmartTable from "../../common/FortConSmartTable";
    import FortConConfirm from "../../utils/FortConConfirm";

    export default {
        components: {
            FortConHeader,
            FortConSmartTable,
            FortConConfirm
        },
        computed: {
            ...mapGetters(["account","requiredFieldRule","emailValidationRules"]),
        },
        data() {
            return {
                addDialog: false,
                loading: false,
                admins: [],
                seats: 0,
                listUrl: "/api/v1/account?getAllAdmins",
                viewUrl: "/api/v1/user/{id}",
                updateUrl: "/api/v1/user/{id}",
                deleteUrl: "/api/v1/user/{id}",
                newUser: {
                    first_name: null,
                    last_name: null,
                    email: null,
                    attributes: {
                        phone: null,
                        mobile: null,
                        ext: null,
                        profile_image: null
                    }
                },
                key: 1
            }
        },
        methods: {
            addUser() {
                this.loading = true;
                axios.post('/api/v1/users', this.newUser)
                    .then(response => {
                        this.key += 1;
                        this.addDialog = false;
                        this.loading = false;
                        this.$store.dispatch("fetchUserData");
                        bus.$emit('alert', response.data);
                    }).catch(err => {
                        this.loading = false;
                        bus.$emit('error', {
                            displayAlert: 'error',
                            message: 'Something went bang! Contact support ASAP!'
                        })
                    });
            },
            toggleUpdateForm(user) {
                // grab the user's data from the server
                axios.get('/api/v1/users/' + user.id)
                    .then(response => {
                        let userData = response.data;

                        this.newUser = {
                            first_name: user.first_name,
                            last_name: user.last_name,
                            email: user.email,
                            attributes: {
                                job_title: use
                            }
                        }
                    })
            },
            updateUser() {

            },
            deleteUser(user, confirmed) {
                if (!confirmed) {
                    this.$store.dispatch('askConfirmation', {
                        title: 'Confirm action',
                        body: 'Are you sure you wish to delete this user?',
                    }).then(confirmation => {
                        if (confirmation)
                            this.deleteUser(user, true);
                    });
                }
                else {
                    axios.delete('/api/v1/users/' + user.id)
                        .then(response => {
                            this.$store.dispatch("fetchUserData");
                            bus.$emit('alert', {
                                displayAlert: 'success',
                                message: `User ${user.first_name} ${user.last_name} deleted successfully`
                            });
                        });
                    this.key += 1;
                }
            }
        },
        mounted() {}
    }
</script>
