<template>
    <div>
        <fort-con-header bc-override="dashboard"/>
    </div>
</template>

<script>
    import FortConHeader from "../utils/FortConHeader";
    export default {
        components: {
            FortConHeader
        }
    }
</script>
