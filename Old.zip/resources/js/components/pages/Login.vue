<template>
    <v-row align="center" justify="center">
        <v-col cols="12" xs="12" sm="12" md="7" class="hidden-sm-and-down">
            <v-img src="../../../img/3372237.svg"></v-img>
        </v-col>
        <v-col cols="12" xs="12" sm="12" md="3" class="pa-sm-10">
            <transition name="slide-fade" mode="out-in">
                <div :key="show" v-if="show === 'login'">
                    <h1 class="thin font-weight-light">Welcome back :)</h1>
                    <p>To keep connecting with us please sign in with your personal info.</p>
                    <v-form ref="form" lazy-validation>
                        <div class="mt-8">
                            <v-text-field
                                v-model="auth.email"
                                label="Email address"
                                placeholder="email@example.com"
                                :rules="emailValidationRules"
                                prepend-inner-icon="mdi-at"
                                filled
                            ></v-text-field>
                            <v-text-field
                                v-model="auth.password"
                                label="Password"
                                prepend-inner-icon="mdi-textbox-password"
                                :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                                :rules="requiredFieldRule"
                                :type="showPassword ? 'text' : 'password'"
                                @click:append="showPassword = !showPassword"
                                filled
                            ></v-text-field>
                        </div>
                        <div>
                            <v-row no-gutters>
                                <v-col cols="12" sm="6" md="6">
                                    <v-checkbox class="mt-0" v-model="auth.remember_me" label="Remember me"></v-checkbox>
                                </v-col>
                                <v-col cols="12" sm="6" md="6" class="text-end">
                                    <small>Forgot password?</small>
                                </v-col>
                            </v-row>
                            <v-row no-gutters>
                                <v-col cols="12" sm="6" md="6">
                                    <v-btn @click="signIn" depressed rounded color="primary" dark>Let's do this</v-btn>
                                </v-col>
                                <v-col cols="12" sm="6" md="6" class="text-end">
                                    <v-btn rounded @click="show = 'register'">Setup a new account</v-btn>
                                </v-col>
                            </v-row>
                        </div>
                    </v-form>
                </div>
                <div :key="show" v-else>
                    <h1 class="thin font-weight-light">Registration</h1>
                    <p>Register your account now or request access to account.</p>
                    <div class="mt-8">
                        <v-text-field
                            v-model="registration.email"
                            label="Email address"
                            placeholder="john.doe@example.com"
                            :rules="emailValidationRules"
                            prepend-inner-icon="mdi-at"
                            filled
                        ></v-text-field>
                        <v-text-field
                            v-model="registration.password"
                            label="Password"
                            prepend-inner-icon="mdi-textbox-password"
                            :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                            :rules="requiredFieldRule"
                            :type="showPassword ? 'text' : 'password'"
                            @click:append="showPassword = !showPassword"
                            filled
                        ></v-text-field>
                    </div>
                    <div>
                        <v-btn @click="register" depressed rounded color="primary" dark>Begin registration</v-btn>

                        <div class="mt-10 mb-5">
                            <small>Already have an account?</small>
                        </div>
                        <v-btn rounded @click="show = 'login'">Login</v-btn>
                    </div>
                </div>
            </transition>
        </v-col>
    </v-row>
</template>

<script>
    import { mapGetters } from "vuex";
    import Cookies from "js-cookie";

    export default {
        computed: {
            ...mapGetters(["requiredFieldRule","emailValidationRules", "domain"])
        },
        data() {
            return {
                showPassword: false,
                password: 'Password',
                rules: {
                    required: value => !!value || 'Required.',
                    min: v => v.length >= 6 || 'Min 6 characters',
                    emailMatch: () => ('The email and password you entered don\'t match'),
                },
                auth: {
                    email: null,
                    password: null,
                    remember_me: false
                },
                registration: {
                    email: null,
                    password: null
                },
                show: 'login'
            }
        },
        methods: {
            signIn() {
                if (this.$refs.form.validate()) {
                    axios.post('/api/v1/public/login?performLogin', this.auth)
                        .then(response => {
                            if (response.data.hasOwnProperty('token')) {
                                this.$store.dispatch('authenticate', response.data).then(() => {
                                    this.$store.dispatch("fetchUserData").then(() => {
                                        let redirect = '/dashboard';
                                        if (this.$route.query.redirect) {
                                            redirect = this.$route.query.redirect;
                                        }

                                        this.$router.push(redirect);
                                    });
                                });
                            } else {
                                bus.$emit('alert', response.data);
                            }
                        });
                }
            },
            register() {

            }
        },
        mounted() {
            //console.log(Cookies.get('token'));
        }
    }
</script>
