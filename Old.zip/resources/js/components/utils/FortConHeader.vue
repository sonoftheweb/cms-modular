<template>
    <div class="mb-10">
        <fort-con-breadcrumb :over-ride="bcOverride"/>
        <fort-con-page-title :provided-title="providedTitle"/>
    </div>
</template>

<script>
    import FortConPageTitle from "../utils/FortConPageTitle";
    import FortConBreadcrumb from "../utils/FortConBreadcrumb";

    export default {
        props: ["providedTitle", "bcOverride"],
        components: {
            FortConPageTitle,
            FortConBreadcrumb
        },
    }
</script>

<style scoped>

</style>
