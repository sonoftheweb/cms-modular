<template>
    <p class="headline">{{ title }}</p>
</template>

<script>
    export default {
        props: ["providedTitle"],
        data() {
            return {
                title: null
            }
        },
        mounted() {
            if (this.providedTitle) {
                this.title = this.providedTitle;
            } else {
                if (this.$route.meta.hasOwnProperty('displayableName')) {
                    this.title = this.$route.meta.displayableName;
                }
            }
        }
    }
</script>
