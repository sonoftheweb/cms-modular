<template>
    <div>
        <v-data-table
            v-model="selected"
            :headers="headers"
            :items="tableData"
            item-key="id"
            :show-select="selectable"
            :loading="loading"
            loading-text="Loading... Please wait"
            :server-items-length="totalDataCount"
            :options.sync="options"
        >
            <template v-slot:top>
                <v-toolbar flat color="white" class="table-tool-bar mb-10">
                    <v-text-field
                        v-if="searchable"
                        v-model="search"
                        solo-inverted
                        flat
                        hide-details
                        label="Search..."
                        prepend-inner-icon="mdi-magnify"
                        class="table-search"
                    />
                    <v-spacer/>

                    <v-btn small dark rounded depressed color="success" class="mb-2" @click="addItem">
                        <v-icon class="mr-2">mdi-plus</v-icon>
                        Add
                    </v-btn>

                    <v-btn small dark rounded depressed color="error" class="mb-2 ml-3" v-if="selected.length">
                        <v-icon class="mr-2">mdi-delete-sweep-outline</v-icon>
                        Delete
                    </v-btn>

                </v-toolbar>
            </template>
            <template v-slot:item.actions="{ item }">
                <v-btn class="float-right ml-5" depressed color="error" small rounded @click="deleteItem(item)">
                    <v-icon class="mr-2">mdi-delete-sweep-outline</v-icon>
                </v-btn>
                <v-btn class="float-right" depressed color="warning" small rounded @click="editItem(item)">
                    <v-icon small class="mr-2">mdi-pencil-outline</v-icon>
                    Edit
                </v-btn>
            </template>
        </v-data-table>
    </div>
</template>

<script>
    export default {
        props: [
            "selectable",
            "url",
            "view",
            "update",
            "delete",
            "searchable"
        ],
        data() {
            return {
                loading: false,
                add: false,
                pagination: {
                    itemsPerPage: 10,
                    page: 1,
                    pageCount: 0,
                    sort: {
                        field: null,
                        direction: 'asc'
                    }
                },
                search: null,
                selected: [],
                headers: [],
                tableData: [],
                totalDataCount: 0,
                options: {
                    page: 1,
                    itemsPerPage: 10
                },
            }
        },
        watch: {
            tableData() {
                this.prepareData();
            },
            options: {
                handler () {
                    this.fetchData();
                },
                deep: true,
            },
            search() {
                this.debounceFetchData();
            }
        },
        methods: {
            prepareData() {
                //lets build the headers first
                if (this.tableData.length < 1) {
                    //do not show the table
                    // show no data
                    return;
                }

                let headers = Object.keys(this.tableData[0]);
                this.headers = [];

                for (let i = 0; i < headers.length; i++) {
                    let value = headers[i];
                    headers[i] = this.camelize(headers[i]);
                    headers[i] = this.deCamelize(headers[i], ' ');
                    this.headers.push({
                        text: headers[i],
                        align: 'start',
                        sortable: true,
                        value: value,
                    });
                }

                this.headers.push({ text: '', value: 'actions', sortable: false });

                this.loading = false;
            },
            camelize(text) {
                return text.replace(/^([A-Z])|[\s-_]+(\w)/g, function(match, p1, p2, offset) {
                    if (p2) return p2.toUpperCase();
                    return p1.toLowerCase();
                });
            },
            deCamelize(str, separator){
                separator = typeof separator === 'undefined' ? ' ' : separator;

                str = str
                    .replace(/([a-z\d])([A-Z])/g, '$1' + separator + '$2')
                    .replace(/([A-Z]+)([A-Z][a-z\d]+)/g, '$1' + separator + '$2')
                    .toLowerCase();

                return this.titleCase(str);
            },
            titleCase(string) {
                let sentence = string.split(" ");
                for(let i = 0; i< sentence.length; i++){
                    sentence[i] = sentence[i][0].toUpperCase() + sentence[i].slice(1);
                }
                sentence = sentence.join(" ");
                return sentence;
            },
            async fetchData() {
                if (this.loading) {
                    return;
                }
                this.loading = true;

                let url = this.url;

                url = this.appendUrl(url, 'perPage', this.options.itemsPerPage);
                url = this.appendUrl(url, 'page', this.options.page);

                if (this.search != null) {
                    url = this.appendUrl(url, 'search', this.search);
                }

                if (this.options.sortBy.length) {
                    let dir = (this.options.sortDesc[0]) ? 'desc' : 'asc';
                    url = this.appendUrl(url, 'sortDir', dir);
                    url = this.appendUrl(url, 'sortBy', this.options.sortBy[0]);
                }

                await axios.get(url)
                    .then(response => {
                        this.tableData = response.data.data.items;
                        this.totalDataCount = response.data.data.totalItems;
                        if (this.tableData.length < 1)
                            this.loading = false;
                    });
            },
            appendUrl(url, param, value) {
                if (url.indexOf(param) === -1) {
                    let sep = url.indexOf("?") === -1 ? "?" : "&";
                    return url + sep + param + "=" + value;
                }
                return url;
            },
            save() {

            },
            close() {

            },
            debounceFetchData: _.debounce(function() {
                this.fetchData();
            }, 800),
            addItem() {
                this.$emit('add-item');
            },
            editItem(item) {
                this.$emit('edit-item', item);
            },
            deleteItem(item) {
                this.$emit('delete-item', item);
            },
        },
        mounted() {
            this.fetchData();
        }
    }
</script>
