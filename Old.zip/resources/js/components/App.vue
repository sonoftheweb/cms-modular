<template>
    <div>
        <fortcon-alerts :alert-data="alertData" class="fortcon-alert"/>
        <v-app v-if="!loggedIn">
            <router-view></router-view>
        </v-app>
        <v-app v-else>
            <fort-con-app-bar/>
            <menu-one></menu-one>
            <v-content>
                <v-container fluid class="pa-10">
                    <router-view></router-view>
                </v-container>
            </v-content>
        </v-app>
    </div>
</template>

<script>
    import { mapGetters } from "vuex";
    import MenuOne from "./menu/MenuOne";
    import MenuTwo from "./menu/MenuTwo";
    import FortconAlerts from "./menu/FortconAlerts";
    import FortConAppBar from "./menu/FortConAppBar";

    export default {
        computed: {
            ...mapGetters(["loggedIn"])
        },
        data: () => ({
            alertData: {},
            showMenu: true,
            mainWidth: {
                secMenu: 2,
                content: 10
            },
            contentPaddingClass: 'expandedMenuContentClass',
            menuExpanded: true
        }),
        components: {
            MenuOne,
            MenuTwo,
            FortconAlerts,
            FortConAppBar
        },
        mounted() {
            bus.$on("alert", alertData => {
                this.alertData = alertData;
            });
            bus.$on("hide-menu", () => {
                this.showMenu = false;
            });
            bus.$on("show-menu", () => {
                this.showMenu = true;
            });
            bus.$on("expanded", (truthy) => {
                if (!truthy) {
                    this.mainWidth.secMenu = 1;
                    this.mainWidth.content = 11;
                    this.menuExpanded = false;
                } else {
                    this.mainWidth.secMenu = 2;
                    this.mainWidth.content = 10;
                    this.menuExpanded = true;
                }
            });
        }
    }
</script>
