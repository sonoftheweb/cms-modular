<template>
    <v-navigation-drawer dark :mini-variant="mini" app clipped color="indigo darken-4">
        <!--<v-btn x-small text exact icon class="mx-4 mt-5 mb-10" @click="mini = !mini"><v-icon>mdi-arrow-left-circle-outline</v-icon></v-btn>-->
        <v-list dense class="indigo darken-4 mt-8">
            <template v-for="(item, i) in menuData">
                <v-list-item :key="i" @click="toLink(item.link)">
                    <v-list-item-action>
                        <v-icon>{{ item.icon }}</v-icon>
                    </v-list-item-action>
                    <v-list-item-content>
                        <v-list-item-title class="grey--text">
                            {{ item.tk_name }}
                        </v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
            </template>
        </v-list>
    </v-navigation-drawer>
</template>

<script>
import { mapGetters } from 'vuex';

    export default {
        computed: {
            ...mapGetters(["menuData"])
        },
        data: () => ({
            mini: true,
            drawer: null
        }),
        methods: {
            toLink(link) {
                if (link) {
                    this.$router.push(link);
                }
            }
        },
        mounted() {
            bus.$on('toggle-menu', () => {
                this.mini = !this.mini;
            });
        }
    }
</script>

<style scoped>

</style>
