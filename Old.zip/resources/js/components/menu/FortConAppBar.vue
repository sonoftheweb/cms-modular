<template>
    <v-app-bar dense app dark fixed flat clipped-left color="indigo darken-4">
        <v-app-bar-nav-icon @click="toggleMenu" />
        <span class="title ml-3 mr-5">Fort&nbsp;<span class="font-weight-light">Con</span></span>

        <v-progress-linear
            v-if="isLoading"
            active
            indeterminate
            absolute
            bottom
            color="indigo lighten-4"
        ></v-progress-linear>

        <v-spacer />

        <v-text-field
            dense
            solo-inverted
            flat
            hide-details
            label="Search everything..."
            prepend-inner-icon="mdi-magnify"
        />

        <v-spacer />

        <v-avatar class="ml-3 mr-2" color="indigo" size="24">
            <v-icon dark>mdi-account-circle</v-icon>
        </v-avatar>
    </v-app-bar>
</template>

<script>
    export default {
        data() {
            return {
                isLoading: false
            }
        },
        methods: {
            toggleMenu() {
                bus.$emit('toggle-menu');
            }
        },
        mounted() {
            bus.$on('toggle-loading', (val) => {
                this.isLoading = val;
            });
        }
    }
</script>
