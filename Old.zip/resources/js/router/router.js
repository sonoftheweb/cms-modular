import Vue from "vue";
import VueRouter from "vue-router";
import routes from "./routes";
import store from "../store/index";

Vue.use(VueRouter);

const router = new VueRouter({
    routes: routes,
    mode: 'history'
});

router.initialize = async () => {
    router.beforeEach(async (to, from, next) => {
        // check some things here before allowing to the next page
        // if there is a cookie having token for this session and there is no user data in store
        if (store.getters.needUserData && store.getters.authenticated){
            await store.dispatch("fetchUserData");
        }

        // user has a cookie and is moving from page to page (active user) but not from the login page
        if (store.getters.loggedIn) {
            store.dispatch('refreshSession');
            if (to.name === 'login')
                return router.push(('/dashboard'));
        }

        // user has cookie and is going from the login page to the logout page
        if (store.getters.loggedIn && from.name === 'login' && to.name === 'logout') {
            if (to.name === 'logout' && from.name === 'login') {
                return router.push('/dashboard');
            }
        }

        // page requires authentication, BUT the user does not have cookies and user data is needed
        if (to.meta.requiresAuth && !store.getters.loggedIn && !store.getters.needUserData) {
            return router.push('/login?redirect=' + to.path);
        }

        if (to.meta.requiresAuth && !store.getters.hasSubscription) {
            return router.push('/subscribe');
        }

        /*if (to.meta.guard) {
            let hasAccess = false;
            for (let guard in to.meta.guard) {
                guard = to.meta.guard[guard];
                if (store.getters.hasRole(guard)) {
                    hasAccess = true;
                    break;
                }
            }
            if (!hasAccess) {
                return router.push('/home');
            }
        }*/

        // One last check to see if user has an account and trigger a backend fetch before redirecting


        next();
    });
};

export default router;
