import Login from "../components/pages/Login";
import Dashboard from "../components/pages/Dashboard";
import FortConNoAccount from "../components/pages/account/FortConNoAccount";
import FortConSubscribe from "../components/pages/FortConSubscribe";
import FortConPayment from "../components/pages/FortConPayment";
import FortConUsers from "../components/pages/users/FortConUsers";

export default [
    {
        path: '/',
        name: 'login',
        component: Login,
        meta: { requiresAuth: false }
    },
    {
        path: '/login',
        name: 'login-alt',
        component: Login,
        meta: { requiresAuth: false }
    },
    {
        path: '/setup-account',
        name: 'setup_account',
        component: FortConNoAccount,
        meta: { requiresAuth: true }
    },
    {
        path: '/subscribe',
        name: 'subscribe',
        component: FortConSubscribe,
        meta: { requiresAuth: false }
    },
    {
        path: '/payment',
        name: 'payment',
        component: FortConPayment,
        props: true,
        meta: { requiresAuth: false, displayableName: 'Make Payment' }
    },
    {
        path: '/dashboard',
        name: 'dashboard',
        component: Dashboard,
        meta: { requiresAuth: true, guard: ['role_admin', 'role_super'], displayableName: 'Dashboard' }
    },
    {
        path: '/users',
        name: 'users',
        component: FortConUsers,
        meta: { requiresAuth: true, guard: ['role_admin', 'role_super'], displayableName: 'Manage Users' }
    }
];
