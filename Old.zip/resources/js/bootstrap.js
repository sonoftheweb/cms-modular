import lodash from "lodash";
import axios from "axios";
import router from "./router/router";
import store from "./store/index";
import Cookies from "js-cookie";

window._ = lodash;

/**
 * We'll load jQuery and the Bootstrap jQuery plugin which provides support
 * for JavaScript based Bootstrap features such as modals and tabs. This
 * code may be modified to fit the specific needs of your application.
 */

try {
    window.Popper = require('popper.js').default;
} catch (e) {}

window.consoleGood = '(☞ﾟヮﾟ)☞ ===>';
window.consoleBad = '(┛ಠ_ಠ)┛彡┻━┻ ===>';

/**
 * We'll load the axios HTTP library which allows us to easily issue requests
 * to our Laravel back-end. This library automatically handles sending the
 * CSRF token as a header based on the value of the "XSRF" token cookie.
 */
window.axios = axios;
window.no_account = false;

let token = document.head.querySelector('meta[name="csrf-token"]');
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
window.axios.defaults.withCredentials = true;
//window.axios.defaults.baseURL = 'http://fortcon.local';

/*if (token) {
    window.axios.defaults.headers.common['X-CSRF-TOKEN'] = token.content;
} else {
    console.error('CSRF token not found: https://laravel.com/docs/csrf#csrf-x-csrf-token');
}*/

window.axios.interceptors.request.use(config => {
    bus.$emit('toggle-loading', true);
    if (!Cookies.get('token') && store.getters.loggedIn) {
        store.dispatch('loggedOut');
        router.push('/');
        return;
    }

    // add access tokens to the request IF access tokens exist
    if (Cookies.get('token')) {
        config.headers.common['Authorization'] = Cookies.get('token');
    }

    return config;
}, error => {
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    bus.$emit('toggle-loading', false );
    if (response.data.hasOwnProperty('has_no_account') && response.data.has_no_account) {
        window.bus.$emit('hide-menu');
        router.push('/setup-account');
    }
    /*if (response.data.hasOwnProperty('has_no_subscription') && response.data.has_no_subscription) {
        window.bus.$emit('hide-menu');
        router.push('/subscribe');
    }*/

    if (response.data.hasOwnProperty('redirect_to_logout') && response.data.redirect_to_logout) {
        store.dispatch('loggedOut');
    }

    return response;
}, error => {

    if (error.response && error.response.data && error.response.data.message === 'redirect-after-logout') {
        store.dispatch('loggedOut').then(() => {
            window.location.href = '/';
        });
        return;
    }

    if (error.response.status === 401) {
        store.dispatch('loggedOut').then(() => {
            router.push("/");
        });
        return;
    }

    if (error.response && error.response.data) {
        // show the error on screen
        //bus.$emit('alert', error.response.data);
    }

    return Promise.reject(error);
});

/**
 * Echo exposes an expressive API for subscribing to channels and listening
 * for events that are broadcast by Laravel. Echo and event broadcasting
 * allows your team to easily build robust real-time web applications.
 */

// import Echo from 'laravel-echo';

// window.Pusher = require('pusher-js');

// window.Echo = new Echo({
//     broadcaster: 'pusher',
//     key: process.env.MIX_PUSHER_APP_KEY,
//     cluster: process.env.MIX_PUSHER_APP_CLUSTER,
//     encrypted: true
// });
