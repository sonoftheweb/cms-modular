import {loadStripe} from '@stripe/stripe-js';

export default {
    initialize: async () => {
        await loadStripe(process.env.MIX_STRIPE_KEY);
    }
}
