<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model;
use Faker\Generator as Faker;

$factory->define(\App\Models\UserAttribute::class, function (Faker $faker) {
    return [
        'phone' => $faker->phoneNumber,
        'mobile' => $faker->phoneNumber,
        'active' => true
    ];
});
