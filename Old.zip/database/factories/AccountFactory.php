<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model;
use Faker\Generator as Faker;

$factory->define(\App\Models\Account::class, function (Faker $faker) {
    return [
        'name' => $faker->company,
        'email' => $faker->companyEmail,
        'settings' => json_encode([
            'currency' => $faker->currencyCode,
            'updates' => $faker->numberBetween(1, 5)
        ]),
        'attributes' => json_encode([
            'address' => $faker->address,
            'phone' => $faker->phoneNumber
        ])
    ];
});
