<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\File;

class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $json = File::get(base_path("database/data/menu.json"));
        $menuItems = json_decode($json, true);

        foreach ($menuItems as $menu)
        {
            \App\Models\Menu::create([
                'tk_name' => $menu['tk_name'],
                'icon' => $menu['icon'],
                'link' => $menu['link']
            ]);
        }
    }
}
