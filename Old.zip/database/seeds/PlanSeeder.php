<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\File;

class PlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $plans = \App\Helpers\StripeHelper::getPlans(true);

        foreach ($plans as $plan) {
            \App\Models\Plan::create($plan);
        }
    }
}
