<?php

use Illuminate\Database\Seeder;

class AccountsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Models\Account::class, 3)->create()->each(function ($account) {
            // create stripe accounts
            $account->createAsStripeCustomer([
                'email' => $account->email,
                'name' => $account->name
            ]);

            // Add three random user to the account
            factory(App\Models\User::class, 3)->create([
                'account_id' => $account->id
            ])->each(function($user) {
                factory(App\Models\UserAttribute::class)->create([
                    'user_id' => $user->id
                ]);
            });
        });
    }
}
