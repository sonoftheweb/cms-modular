<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['prefix' => 'v1/public'], function () {
    Route::get('{resource}', 'Api\ApiController@publicGetResource');
    Route::post('{resource}', 'Api\ApiController@publicPostResource');
});

Route::group(['prefix' => 'v1/payment', 'middleware' => ['auth:api', 'has_account']], function () {
    Route::get('paymentMethods', 'Api\PaymentController@getPaymentMethod');
    Route::post('savePaymentMethod', 'Api\PaymentController@savePaymentMethod');
    Route::get('paymentIntent', 'Api\PaymentController@paymentIntent');
    Route::post('subscribe', 'Api\PaymentController@subscribe');
});

// Routes for folks with and account and account has an active subscription
Route::group(['prefix' => 'v1', 'middleware' => ['auth:api', 'has_account', 'has_subscription']], function () {
    Route::get('{resource}', 'Api\ApiController@getResources');
    Route::get('{resource}/{id}', 'Api\ApiController@getResource');
    Route::post('{resource}', 'Api\ApiController@createResource');
    Route::post('{resource}/{id}', 'Api\ApiController@updateResource');
    Route::delete('{resource}/{id}', 'Api\ApiController@deleteResource');
});
