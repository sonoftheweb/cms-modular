<?php


namespace App\Traits;


use App\Exceptions\RequestValidationException;
use App\Helpers\SanitizeRequestHelper;
use Illuminate\Support\Facades\Validator;

trait ValidateRequest
{
    /**
     * Sanitize and validate given request, or if not, the current request().
     * TODO extend the usage of this function to all our controllers
     *
     * @param string $functionName
     * @param array $params
     * @param $request
     * @return bool
     * @throws RequestValidationException
     */
    public function sanitizeAndValidateRequest($functionName, $params = [], $request = null)
    {
        if(!isset($request)) $request = request();
        SanitizeRequestHelper::sanitize($params);
        return $this->validateRequest($functionName, $request);
    }

    /**
     * Validate request for current transformer
     *
     * @param string $functionName
     * @param null $request
     * @return bool
     * @throws RequestValidationException
     */
    public function validateRequest($functionName, $request = null)
    {
        if(!isset($request)) $request = request();

        // Apply posted data validation
        $rules = $this->transformerValidationRules($functionName);

        // If no rules are required, do not validate request
        if (empty($rules['rules'])) {
            return true;
        }

        $validator = Validator::make($request->all(), $rules['rules'], $rules['messages']);
        if ($validator->fails()) {
            throw new RequestValidationException($validator->errors()->first());
        }

        return true;
    }

    /**
     * Default field validation rules. Will be added to the function validation rules such as createItemValidationRules
     * in order to get some default validation rules for all controllers
     *
     * @return array
     */
    public function defaultValidationRules()
    {
        return [
            'rules' => [
                //
            ],
            'messages' => [
                '*.required' =>  __('messages.ui_validation_required'),
                '*.integer' => __('messages.ui_validation_integer'),
                '*.boolean' => __('messages.ui_validation_boolean')
            ]
        ];
    }

    /**
     * Get specific controller validation rules
     *
     * @param string $functionName
     * @return array
     */
    protected function transformerValidationRules($functionName)
    {
        $rules = [];

        // Get function that has called the sanitize function and get validations rules depending on the function name.
        // E.g. if the createItem function try to validate request, we call createItemValidationRules function to get
        // validation rules.
        $functionName = $functionName . 'ValidationRules';
        if (method_exists($this, $functionName)) {
            $rules = $this->$functionName();
        }

        // Apply default validation rules also (See \App\Traits\ValidateRequest::defaultValidationRules) but are override
        // by custom function validation (e.g. createItemRequestValidationRule)
        if (method_exists($this, 'defaultValidationRules')) {
            $rules = array_merge($this->defaultValidationRules(), $rules);
        }

        return $this->mapValidationRules($rules);
    }

    /**
     * Map rules with custom validation rules classes (See the list in App\Rules\)
     *
     * @param $rules
     * @return mixed
     */
    protected function mapValidationRules($rules)
    {
        // If no rules provided by transformer, nothing to do
        if (empty($rules['rules'])) {
            return $rules;
        }

        foreach ($rules['rules'] as &$rule) {
            foreach ($rule as &$validationRule) {
                $ruleClassName = '\App\Rules\\' . $validationRule;
                if (class_exists($ruleClassName)) {
                    $validationRule = new $ruleClassName();
                }
            }
        }

        return $rules;
    }
}
