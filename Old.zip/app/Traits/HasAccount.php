<?php


namespace App\Traits;


trait HasAccount
{
    public function account()
    {
        return $this->belongsTo('App\Models\Account');
    }
}
