<?php


namespace App\Traits;


trait HasUser
{
    public function users()
    {
        return $this->hasMany('App\Models\User');
    }
}
