<?php

namespace App\Http\Middleware;

use App\Http\Controllers\Api\ApiController;
use App\Models\Plan;
use App\Models\User;
use Closure;
use Illuminate\Support\Facades\Auth;

class AccountHasSubscription
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = Auth::id();
        $user = User::where('id', $user)->with('account')->first();

        $plans = Plan::all()->toArray();
        $plans = array_map(function ($plan) {
            return $plan['stripe_plan_identifier'];
        }, $plans);

        if ($user->account->subscribedToPlan($plans, 'default')) {
            return $next($request);
        }

        return response(['has_no_subscription' => true], 200);
    }
}
