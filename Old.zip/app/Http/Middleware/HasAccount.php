<?php

namespace App\Http\Middleware;

use App\Helpers\AccountHelper;
use App\Http\Controllers\Api\ApiController;
use App\Models\User;
use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class HasAccount
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $account = AccountHelper::getAccount();
        if (empty($account))
            return response(['has_no_account' => true], 200);

        return $next($request);
    }
}
