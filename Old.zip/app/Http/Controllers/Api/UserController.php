<?php

namespace App\Http\Controllers\Api;

use App\Helpers\AccountHelper;
use App\Models\Menu;
use App\Models\NewRegistrantsData;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class UserController extends BaseController
{
    public function me(Request $request, $definition)
    {
        $me = Auth::user();
        $me->load('role');

        $me = $me->toArray();
        $account = AccountHelper::getAccount();
        $account->settings = json_decode($account->settings, true);
        $subscription = $account->subscription();

        // get the menu for this user once
        // not sure I should be doing a different call to backend when I can just load it up here
        // Will still the API endpoint open for the front-end to call
        $menu = Menu::all();

        $data = array_merge($me, [
            'account' => $account,
            'subscription' => $subscription,
            'menu' => $menu
        ]);

        return [
            "data" => $data
        ];
    }

    /**
     * Create a new user
     *
     * @param Request $request
     * @param $definition
     * @return string|void
     * @throws \Exception
     */
    public function createItem(Request $request, $definition)
    {
        //check the number of seats in the account
        $account = AccountHelper::getAccount();
        $accountSettings = json_decode($account->settings, true);
        $usersInThisAccount = $account->administrators()->count();

        if ($accountSettings['seats'] <= $usersInThisAccount) throw new \Exception('Number of users exceeded. Get more seats.');

        // validate data
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|max:20',
            'last_name' => 'required|max:20',
            'email' => 'required|unique:users,email|max:100',
            'attributes.job_title' => 'required',
            'attributes.phone' => 'required',
            'attributes.address' => 'required'
        ]);

        if ($validator->fails()) throw new \Exception('Validation failed');
        $validated = $validator->validated();

        $password = Hash::make(Str::random(8));

        // create the user
        $user = new User;
        $user->first_name = $validated['first_name'];
        $user->last_name = $validated['last_name'];
        $user->email = $validated['email'];
        $user->password = $password;
        $user->role_id = Config::get('constants.roles.role_admin');
        $user->account_id = $account->id;
        $user->attributes = json_encode($validated['attributes']);
        $user->save();

        // add user to new details table
        NewRegistrantsData::create([
            'user_id' => $user->id,
            'account_id' => $account->id
        ]);

        // reduce the number of seats available by 1
        $accountSettings['seats'] -= 1;
        $account->settings = json_encode($accountSettings);
        $account->save();

        // send a mail to the new user email with details

        return 'User successfully added to account.';
    }
}
