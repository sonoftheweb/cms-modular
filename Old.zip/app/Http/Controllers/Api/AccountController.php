<?php

namespace App\Http\Controllers\Api;

use App\Helpers\AccountHelper;
use App\Helpers\SearchAndPaginateHelper;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

class AccountController extends BaseController
{
    protected $relations = [
        'administrators',
        'customers'
    ];

    public function getAllAdmins(Request $request, array $definition): array
    {
        $administrators = User::where('account_id', AccountHelper::getAccountId())->where('role_id', Config::get('constants.roles.role_admin'));
        $administrators = SearchAndPaginateHelper::BuildSearchAndPagination($request, $administrators, 'User');

        return [
            'data' => $administrators
        ];
    }
}
