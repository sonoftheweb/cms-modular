<?php

namespace App\Http\Controllers\Api\PublicAccess;

use App\Http\Controllers\Api\BaseController;
use App\Models\Plan;
use Illuminate\Http\Request;

class PlanController extends BaseController
{
    protected $product;

    public function __construct()
    {
        $this->product = env('STRIPE_MAIN_PRODUCT');
    }

    public function getActivePlans()
    {
        return [
            'data' => Plan::select('nickname', 'metadata', 'tiers')
                ->where('active', 1)
                ->get()
            ];
    }
}
