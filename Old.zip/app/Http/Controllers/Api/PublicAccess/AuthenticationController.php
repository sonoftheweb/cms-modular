<?php

namespace App\Http\Controllers\Api\PublicAccess;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthenticationController extends BaseController
{
    public function performLogin(Request $request, $definition)
    {
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            $token = $user->createToken(strtolower($user->first_name) . '_access')->accessToken;

            $response = [
                'token' => $token
            ];
        }
        else {
            $response = [
                'displayAlert' => 'error',
                'message' => "Incorrect Credentials"
            ];
        }

        return $response;
    }

    public function logout()
    {
        Auth::logout();
    }

    protected function guard()
    {
        return Auth::guard();
    }
}
