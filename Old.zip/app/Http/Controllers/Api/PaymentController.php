<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;

class PaymentController extends Controller
{
    public function getPaymentMethod(Request $request)
    {
        $user = Auth::user();
        $user->load('account');

        $paymentMethods = [];
        foreach($user->account->paymentMethods() as $method){
            $paymentMethods[] = [
                'id' => $method->id,
                'brand' => $method->card->brand,
                'last_four' => $method->card->last4,
                'exp_month' => $method->card->exp_month,
                'exp_year' => $method->card->exp_year,
            ];
        }

        return [
            'data' => ($request->has('count') && $request->count) ? count($paymentMethods) : $paymentMethods
        ];
    }

    public function savePaymentMethod(Request $request)
    {
        $user = Auth::user();
        $user = $user->load('account');
        $user->account->addPaymentMethod($request->payment_method);

        return $this->getPaymentMethod($request);
    }

    public function paymentIntent(Request $request)
    {
        $user = User::findOrFail(Auth::id());
        $user->load('account');

        return [
            'data' => $user->account->createSetupIntent()
        ];
    }

    public function subscribe(Request $request)
    {
        try {
            $user = Auth::user();
            $user->load('account');

            $paymentMethod = $request->pm;
            $plan = $request->plan;
            $seats = $request->seat_count;
            $makeDefault = $request->make_default_payment_method;
            $account = $user->account;

            //get plan by nickname
            $plan = Plan::where('nickname', $plan)->first();
            $plan = $plan->toArray();

            $subscriptionBuilder = $account->newSubscription('default', $plan['stripe_plan_identifier'])->withMetadata([
                'account_name' => $account->name,
                'account_email' => $account->email,
                'account_seats' => $seats
            ]);

            if(!$user->account->subscribed('default')){
                $subscriptionBuilder->quantity($seats)->create($paymentMethod['id']);
            }
            else {
                $account->subscription('default')->swap($plan->id);
            }

            $settings = json_decode($account->settings, true);
            $settings['seats'] = $seats;
            $account->settings = json_encode($settings);
            $account->save();

            return Response::json([
                'displayAlert' => 'success',
                'message' => 'You have been successfully subscribed to your selected plan.',
            ], 200, [], JSON_INVALID_UTF8_IGNORE);

        } catch (\Exception $e) {
            return Response::json([
                'displayAlert' => 'error',
                'message' => 'Unable to subscribe your account to a plan. Please contact support. ' . $e->getMessage() . ' File: ' . $e->getFile() . ', Line: ' . $e->getLine() ,
            ], 401, [], JSON_INVALID_UTF8_IGNORE);
        }

    }
}
