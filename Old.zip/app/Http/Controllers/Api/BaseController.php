<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Traits\ValidateRequest;
use Illuminate\Http\Request;

class BaseController extends Controller
{
    use ValidateRequest;

    protected $request = null;

    protected $definition = null;

    protected $relations = [];

    protected $headers = null;

    protected $totalItems = 0;

    /**
     * Get items as a collection
     *
     * @param Request $request
     * @param $definition
     * @return string
     */
    public function getItems(Request $request, $definition)
    {
        return $definition['model']::with($this->relations)->get();
    }

    /**
     * Get singular item
     *
     * @param $id
     * @param Request $request
     * @param $definition
     * @return string
     */
    public function getItem($id, $definition)
    {
        return $definition['model']::findOrFail($id);
    }

    /**
     * Create Resource
     *
     * @param Request $request
     * @param $definition
     * @return string
     */
    public function createItem(Request $request, $definition)
    {
        $definition['model']::create($request->all());

        return "Resource was created successfully";
    }

    /**
     * Update resource
     *
     * @param $definition
     * @param $id
     * @param Request $request
     * @return string
     */
    public function updateItem($definition, $id, Request $request)
    {
        $item = $definition['model']::findOrFail($id);
        if (!empty($item)) {
            foreach ($item->getFillable() as $column) {
                $item->$column = $request->input($column);
            }
            $item->save();
        }

        return "Resource was updated successfully";
    }

    /**
     * Delete directly from model
     *
     * @param $id
     * @param $definition
     */
    public function deleteItem($id, $definition)
    {
        $definition['model']::destroy($id);
    }

    protected function respondError($message, $data = null)
    {
        return $this->respond($message, 'error', $data);
    }

    protected function respondSuccess($message, $data = null)
    {
        return $this->respond($message, 'success', $data);
    }

    protected function respond($message, $type, $data = null)
    {
        $response = [
            $type => __($message)
        ];
        if ($data) {
            $response['data'] = $data;
        }
        if (!empty($this->errors)) {
            $response['errors'] = $this->errors;
        }
        return $response;
    }

    public function loadRelations($items)
    {
        $items->load($this->relations);
    }
}
