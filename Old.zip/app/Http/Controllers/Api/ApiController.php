<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\RequestValidationException;
use App\Helpers\ProtectedResourceHelper;
use App\Helpers\PublicResourceHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Throwable;

class ApiController extends Controller
{
    protected $statusCode = 200;

    /**
     * Status code
     *
     * @return int
     */
    public function getStatusCode()
    {
        return $this->statusCode;
    }

    /**
     * Set status code
     * @param $statusCode
     * @return $this
     */
    public function setStatusCode($statusCode)
    {
        $this->statusCode = $statusCode;
        //we return $this because we sometimes respond stuff like this:
        //$this->setStatusCode(202)->respond('message');
        return $this;
    }

    /**
     * Respond broken to JSON
     *
     * @param $data
     * @return \Illuminate\Http\JsonResponse
     */
    public function respond($data)
    {
        return Response::json($data, $this->getStatusCode(), [], JSON_INVALID_UTF8_IGNORE);
    }

    /**
     * Respond with success message
     *
     * @param $statusCode
     * @param $response
     * @return \Illuminate\Http\JsonResponse
     */
    public function respondWithSuccessMessage($statusCode, $response)
    {
        switch (gettype($response)) {
            case "array":
                return $this->setStatusCode($statusCode)->respond(array_merge([
                    'displayAlert' => 'success'
                ], $response));
            default:
                return $this->setStatusCode($statusCode)->respond([
                    'displayAlert' => 'success',
                    'message' => $response,
                ]);
        }
    }

    /**
     * Respond with success message
     *
     * @param Throwable $throwable
     * @return \Illuminate\Http\JsonResponse
     */
    public function respondWithError(Throwable $throwable)
    {
        $this->setStatusCode($throwable->getCode());

        if (
            $this->statusCode > 700 ||
            $this->statusCode == 0 ||
            $this->statusCode == 42 ||
            $this->statusCode == 22 ||
            $this->statusCode == -1
        ) {
            // Likely an SQL error (for instance: foreign key dependency, not respecting default value...), let's tell them this is not authorized
            $this->setStatusCode(404);
        }

        report($throwable);

        $response = [
            'displayAlert' => 'error',
            'message' => __('messages.error'),
            'error' => [
                'status_code' => $this->getStatusCode()
            ],
        ];

        if (env('APP_DEBUG')) {
            $response = array_merge($response, [
                'message' => $throwable->getMessage(),
                'file' => $throwable->getFile(),
                'line' => $throwable->getLine(),
                'trace' => $throwable->getTraceAsString()
            ]);
        }

        return $this->respond($response);
    }

    /**
     * Respond with error message
     *
     * @param $e
     * @return \Illuminate\Http\JsonResponse
     */
    public function respondWithErrorMessage($e)
    {
        return $this->setStatusCode($e->getCode())->respond([
            'displayAlert' => 'error',
            'message' => $e->getMessage(),
        ]);
    }

    /**
     * Access API from public routes => post to create
     * catches all sub-methods and executes them
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function publicPostResource(Request $request)
    {
        try {
            $definition = PublicResourceHelper::getResourceDefinition($request->resource, $request, true);

            $subMethodsResult = $this->performRequestSubMethodOperation($request, $definition);
            if (!empty($subMethodsResult)) {
                if ($request->resource === 'login')
                    return $subMethodsResult;
                else
                    return $this->respondWithSuccessMessage(201, $subMethodsResult);
            }


            $message = $definition['controller']->createItem($request, $definition);
            return $this->respondWithSuccessMessage(201, $message);
        } catch (RequestValidationException $e) {
            return $this->respondWithErrorMessage($e);
        } catch (\Throwable $e) {
            return $this->respondWithError($e);
        }
    }

    /**
     * API routes => post to create
     * catches all sub-methods and executes them
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function createResource(Request $request)
    {
        try {
            $definition = ProtectedResourceHelper::getResourceDefinition($request->resource, $request);

            $subMethodsResult = $this->performRequestSubMethodOperation($request, $definition);
            if (!empty($subMethodsResult)) {
                return $this->respondWithSuccessMessage(201, $subMethodsResult);
            }

            $message = $definition['controller']->createItem($request, $definition);
            return $this->respondWithSuccessMessage(201, $message);
        } catch (\Throwable $e) {
            return $this->respondWithError($e);
        }
    }

    /**
     * delete resource
     * catches all sub-methods and executes them
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteResource(Request $request)
    {
        try {
            $definition = ProtectedResourceHelper::getResourceDefinition($request->resource, $request);

            $message = $definition['controller']->deleteItem($request->id, $definition);
            return $this->respondWithSuccessMessage(201, $message);
        } catch (\Throwable $e) {
            return $this->respondWithError($e);
        }
    }

    /**
     * Access API from public routes => get
     * catches all sub-methods and executes them
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function publicGetResource(Request $request)
    {
        try {
            $definition = PublicResourceHelper::getResourceDefinition($request->resource, $request, true);

            $subMethodsResult = $this->performRequestSubMethodOperation($request, $definition);
            if (!empty($subMethodsResult)) {
                return $this->respond($subMethodsResult);
            }

            $message = $definition['controller']->getItems($request, $definition);
            return $this->respondWithSuccessMessage(201, $message);
        } catch (RequestValidationException $e) {
            return $this->respondWithErrorMessage($e);
        } catch (\Throwable $e) {
            return $this->respondWithError($e);
        }
    }

    # protected resource section

    public function getResources(Request $request)
    {
        try {
            $definition = ProtectedResourceHelper::getResourceDefinition($request->resource, $request);

            $subMethodsResult = $this->performRequestSubMethodOperation($request, $definition);
            if (!empty($subMethodsResult))
                return $this->respondWithSuccessMessage(201, $subMethodsResult);

            $message = $definition['controller']->getItems($definition);
            return $this->respond($message);
        } catch (RequestValidationException $e) {
            return $this->respondWithErrorMessage($e);
        } catch (\Throwable $e) {
            return $this->respondWithError($e);
        }
    }

    public function getResource(Request $request)
    {
        try {
            $id = (int) $request->id;
            $definition = ProtectedResourceHelper::getResourceDefinition($request->resource, $request);
            $subMethodsResult = $this->performRequestSubMethodOperation($request, $definition, $id);
            if (!empty($subMethodsResult))
                return $this->respondWithSuccessMessage(201, $subMethodsResult);

            $message = $definition['controller']->getItem($id, $definition);
            return $this->respond($message);
        } catch (RequestValidationException $e) {
            return $this->respondWithErrorMessage($e);
        } catch (\Throwable $e) {
            return $this->respondWithError($e);
        }
    }

    #protected

    protected function performRequestSubMethodOperation(Request $request, $definition, $id=null)
    {
        $functions = $this->getRequestFunctions($request);

        foreach ($functions as $function) {
            if (is_string($function) && method_exists($definition['controller'], $function)) {
                return (!$id) ? $definition['controller']->$function($request, $definition) : $definition['controller']->$function($id, $request, $definition);
            }

            if (is_array($function)) {
                foreach ($function as $subFunction) {
                    if (!method_exists($definition['controller'], $subFunction)) {
                        continue;
                    }
                    return (!$id) ? $definition['controller']->$subFunction($request, $definition) : $definition['controller']->$subFunction($id, $request, $definition);
                }
            }
        }

        return null;
    }

    /**
     * Get request functions from request url
     *
     * @param Request $request
     * @return array
     */
    protected function getRequestFunctions(Request $request)
    {
        $functions = ['full' => ''];
        foreach ($request->query() as $key => $value) {
            $functions['full'] .= $this->formatRequestParam($key) . $this->formatRequestParam($value);
            if (!isset($functions[$key])) {
                $functions[$key] = [];
            }
            $functions[$key][] = lcfirst($this->formatRequestParam($key) . $this->formatRequestParam($value));
            $functions[$key][] = lcfirst($this->formatRequestParam($key));
        }
        $functions['full'] = lcfirst($functions['full']);
        return $functions;
    }

    /**
     * Format request params to find possible request functions
     *
     * @param $param
     * @return string|string[]|null
     */
    protected function formatRequestParam($param)
    {
        $param = preg_replace('/[-_]/', ' ', $param);    // hello-world => hello world
        $param = ucwords($param);                                           // hello world => Hello World
        $param = str_replace(' ', '', $param);               // Hello World => HelloWorld
        return $param;
    }
}
