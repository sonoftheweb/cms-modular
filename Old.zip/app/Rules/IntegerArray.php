<?php


namespace App\Rules;


use Illuminate\Contracts\Validation\Rule;

class IntegerArray implements Rule
{

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        if (is_string($value)) {
            $value = json_decode($value);
        }

        if (!is_array($value)) {
            return false;
        }

        foreach($value as $v) {
            if (!is_int($v)) return false;
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function message()
    {
        return "The value for the :attribute field must be an array of integer.";
    }
}
