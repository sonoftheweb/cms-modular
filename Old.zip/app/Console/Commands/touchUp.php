<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;

class touchUp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'touch-up';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run all non breaking seeds... Only meant to seed new data to some selected tables.';

    protected $models = [
        'menus' => 'MenuSeeder'
    ];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        DB::beginTransaction();
        foreach ($this->models as $table => $seeder) {
            // first check if all tables in collection exist
            $exist = DB::select(DB::raw("SELECT COUNT(*) as count
                FROM information_schema.tables
                WHERE table_schema = '" . env('DB_DATABASE') ."'
                AND table_name = '" .$table . "'"
            ));

            if ($exist[0]->count > 0) {
                // wipe it clean
                $this->info('Truncating ' . $table . ' data...');
                DB::statement("TRUNCATE TABLE " . $table);
            } else {
                continue;
            }

            // run seeder
            $this->info('Seeding ' . $table);
            Artisan::call('db:seed --class=' . $seeder);
        }
        DB::commit();
    }
}
