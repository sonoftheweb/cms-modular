<?php

namespace App\Observers;

use App\Helpers\AccountHelper;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class UserObserver
{
    /**
     * Handle the user "created" event.
     *
     * @param \App\Observers\User $user
     * @return void
     */
    public function created(User $user)
    {
        //
    }

    /**
     * Handle the user "updated" event.
     *
     * @param \App\Observers\User $user
     * @return void
     */
    public function updated(User $user)
    {
        //
    }

    /**
     * Handle the user "deleted" event.
     *
     * @param \App\Observers\User $user
     * @return void
     */
    public function deleted(User $user)
    {
        $account = AccountHelper::getAccount();
        $settings = $account->settings;
        $settings = json_decode($settings, true);
        $settings['seats'] = $settings['seats'] + 1;
        $account->settings = json_encode($settings);
        $account->save();
    }

    /**
     * Handle the user "restored" event.
     *
     * @param \App\Observers\User $user
     * @return void
     */
    public function restored(User $user)
    {
        //
    }

    /**
     * Handle the user "force deleted" event.
     *
     * @param \App\Observers\User $user
     * @return void
     */
    public function forceDeleted(User $user)
    {
        //
    }
}
