<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NewRegistrantsData extends ScopableModel
{
    protected $table = 'new_registrant_data';
    protected $fillable = [
        'user_id',
        'account_id'
    ];
}
