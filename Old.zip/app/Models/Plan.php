<?php

namespace App\Models;

use App\Casts\Json;

class Plan extends SimpleModel
{
    protected $casts = [
        'tiers' => 'array',
        'metadata' => 'array'
    ];
}
