<?php

namespace App\Models;

use App\Traits\HasUser;
use Illuminate\Database\Eloquent\Model;

class Role extends SimpleModel
{
    use HasUser;
}
