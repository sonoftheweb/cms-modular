<?php

namespace App\Models;

class UserAttribute extends ScopableModel
{
    protected $fillable = [
        'user_id',
        'phone',
        'ext',
        'mobile',
        'profile_image',
        'active'
    ];

    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id', 'id');
    }
}
