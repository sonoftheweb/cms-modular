<?php

namespace App\Models;

use App\Traits\HasUser;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Laravel\Cashier\Billable;

class Account extends SimpleModel
{
    use HasUser, Billable;

    protected $hidden = [
        'stripe_id', 'card_brand', 'card_last_four'
    ];

    public function administrators()
    {
        return $this->users()->where('role_id', Config::get('constants.roles.role_admin'));
    }

    public function customers()
    {
        return $this->users()->where('role_id', Config::get('constants.roles.role_client'));
    }
}
