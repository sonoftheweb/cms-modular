<?php

namespace App\Models;

class Menu extends SimpleModel
{

}
