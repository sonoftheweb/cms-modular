<?php

namespace App\Models;

use App\Scopes\AccountScope;

class ScopableModel extends SimpleModel
{
    protected static function booted()
    {
        static::addGlobalScope(new AccountScope);
    }
}
