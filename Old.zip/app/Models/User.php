<?php

namespace App\Models;

use App\Helpers\AccountHelper;
use App\Traits\HasAccount;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable, HasAccount;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name', 'last_name', 'email', 'password', 'account_id', 'role_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function attribute()
    {
        return $this->hasOne('App\Models\UserAttribute', 'user_id', 'id');
    }

    public function role()
    {
        return $this->belongsTo('App\Models\Role');
    }

    public function hasRole(string $tk_role, int $accountId = null)
    {
        if ($accountId == null) {
            $accountId = AccountHelper::getAccountId();
        }

        return Cache::remember(
            'user_' . Auth::id() . '_role' . $accountId,
            env('CACHE_TIME_ONE_DAY'),
            function () use ($accountId, $tk_role) {
                $role = $this->role()->first();
                if ($role->tk_role === $tk_role) {
                    return true;
                } else {
                    return false;
                }
            }
        );
    }
}
