<?php


namespace App\Scopes;


use App\Helpers\AccountHelper;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;

class AccountScope implements Scope
{

    /**
     * @inheritDoc
     */
    public function apply(Builder $builder, Model $model)
    {
        $accountID = AccountHelper::getAccountId();
        $builder->where('account_id', $accountID);
    }
}
