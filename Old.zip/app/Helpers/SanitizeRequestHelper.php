<?php


namespace App\Helpers;


use Illuminate\Http\Request;

class SanitizeRequestHelper
{
    /**
     * Properly handle what the front-end sends us.
     * If no request is passed in the arguments, the operation occurs on request().
     *
     * @params array $params
     * @param array $params
     * @param Request|null $request
     * @return Request|void
     */
    public static function sanitize(array $params, Request $request = null)
    {
        $sanitizedRequestArray = [];

        $requestElements = ($request == null) ? request()->all() : $request->all();

        foreach ($requestElements as $requestItemKey => $requestItem) {

            if ($requestItem === 'null' || $requestItem === 'undefined') {
                $requestItem = null;
            }

            if (isset($params['booleanStringsToBooleans']) && $params['booleanStringsToBooleans'] === true) {
                // transform string in booleans if needed
                if ($requestItem === 'true' || $requestItem === 'TRUE') {
                    $requestItem = true;
                }
                if ($requestItem === 'false' || $requestItem === 'FALSE') {
                    $requestItem = false;
                }
            }

            $sanitizedRequestArray[$requestItemKey] = $requestItem;
        }

        // Replace request by sanitized request
        if ($request != null) {
            return $request->replace($sanitizedRequestArray);
        }
        return request()->request->replace($sanitizedRequestArray);
    }
}
