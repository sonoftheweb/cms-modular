<?php


namespace App\Helpers;


use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class AccountHelper
{
    static $account = null;
    const GUARD_TYPE_API = 'api';

    public static function getAccountId()
    {
        $account = self::getAccount();
        if (!$account || is_array($account) || !$account->name) {
            abort(404, 'No account found');
        }
        return $account->id;
    }

    public static function getAccount()
    {
        if (!static::$account) {
            $user = Auth::user() ? Auth::user() : Auth::guard(self::GUARD_TYPE_API)->user();

            $account = $user->account()->first();
            if (!$account || !$account->id) {
                return;
            }

            static::$account = $account;
        }
        return static::$account;
    }
}
