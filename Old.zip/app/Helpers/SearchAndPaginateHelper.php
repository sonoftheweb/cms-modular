<?php


namespace App\Helpers;


use App\Http\Resources\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class SearchAndPaginateHelper
{
    public static function BuildSearchAndPagination(Request $request, Builder $query, $model)
    {
        if ($request->search) {
            $query = SearchAndPaginateHelper::searchClause($request, $query, $model);
        }

        $query = SearchAndPaginateHelper::sortClause($request, $query);

       return self::BuildPagination($request, $query, $model);
    }

    public static function BuildPagination(Request $request, Builder $query, $model)
    {
        $perPage = ($request->has('perPage') && $request->perPage > 0) ? $request->perPage : 10;

        // since model and collection names are the same
        $collection = 'App\Http\Resources\\' . $model;

        $paginated = $collection::collection($query->paginate($perPage));
        $totalItems = $paginated->total();

        $json = json_encode($paginated->items());
        $items = json_decode($json, true);

        return ['items' => $items, 'totalItems' => $totalItems];
    }

    public static function sortClause($request, Builder $query)
    {
        if ($request->sortBy && $request->sortDir === 'asc') {
            $query = $query->orderBy($request->sortBy);
        }

        if ($request->sortBy && $request->sortDir === 'desc') {
            $query = $query->orderByDesc($request->sortBy);
        }

        return $query;
    }

    public static function searchClause($request, Builder $query, $model)
    {
        if ($model === 'User') {
            $query = $query->where('first_name', 'like', '%'.$request->search.'%')
                ->orWhere('last_name', 'like', '%'.$request->search.'%')
                ->orWhere('email', 'like', '%'.$request->search.'%')
                ->orWhere('attributes', 'like', '%'.$request->search.'%');
        }

        return $query;
    }
}
