<?php


namespace App\Helpers;


class ProtectedResourceHelper extends ResourceHelper
{
    public static function resources()
    {
        return [
            'users' => [
                'model' => 'App\Models\User',
                'controller' => 'App\Http\Controllers\Api\UserController'
            ],
            'menus' => [
                'model' => 'App\Models\Menu',
                'controller' => 'App\Http\Controllers\Api\MenuController'
            ],
            'account' => [
                'model' => 'App\Models\Account',
                'controller' => 'App\Http\Controllers\Api\AccountController'
            ]
        ];
    }
}
