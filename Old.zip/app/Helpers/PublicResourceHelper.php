<?php


namespace App\Helpers;


class PublicResourceHelper extends ResourceHelper
{
    public static function resources()
    {
        return [
            'login' => [
                'model' => 'App\Models\User',
                'controller' => 'App\Http\Controllers\Api\PublicAccess\AuthenticationController'
            ],
            'plans' => [
                'model' => 'App\Models\Plan',
                'controller' => 'App\Http\Controllers\Api\PublicAccess\PlanController'
            ]
        ];
    }
}
