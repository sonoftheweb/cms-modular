<?php


namespace App\Helpers;


class ResourceHelper
{
    public static function getResourceDefinition($resource, $request, $public = false)
    {
        $resources = ($public) ? PublicResourceHelper::resources() : ProtectedResourceHelper::resources();

        if (!isset($resources[$resource]))
            abort(404, 'Resource not found');

        $resource = $resources[$resource];
        $resource['controller'] = new $resource['controller']($request);
        $resource['modelShortName'] = (new \ReflectionClass($resource['model']))->getShortName();

        return $resource;
    }
}
