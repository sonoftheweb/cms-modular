<?php

namespace App\Exceptions;

use Exception;
use Throwable;

class RequestValidationException extends Exception
{
    public function __construct($message = "", $code = 0, Throwable $previous = null)
    {
        return parent::__construct($message, 200, $previous);
    }
}
