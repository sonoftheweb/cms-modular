<?php

return [
    'roles' => [
        'role_super' => 1,
        'role_admin' => 2,
        'role_client' => 3,
        'role_legal' => 4,
    ]
];
